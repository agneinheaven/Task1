package com.tests4geeks.tutorials.repository;

import org.springframework.data.repository.CrudRepository;

import com.tests4geeks.tutorials.model.Item;

public interface ItemMongoRepository extends CrudRepository<Item, String>{}