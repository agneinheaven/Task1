package com.tests4geeks.tutorials.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.tests4geeks.tutorials.model.Item;
import com.tests4geeks.tutorials.repository.ItemMongoRepository;
import com.tests4geeks.tutorials.repository.ItemSearchRepository;

@Controller
public class ItemController {

	@Autowired
	ItemMongoRepository itemRepository;
	
	@Autowired
	ItemSearchRepository itemSearchRepository;
	
	@RequestMapping("/home")
	public String home(Model model) {
		model.addAttribute("itemList", itemRepository.findAll());
		return "home";
	}
	
	@RequestMapping(value = "/addItem", method = RequestMethod.POST)
	public String addItem(@ModelAttribute Item item) {
		itemRepository.save(item);
		return "redirect:home";
	}
	
	@RequestMapping(value = "/search")
	public String search(SellIn sellIn, @RequestParam String search) {
		sellIn.addAttribute("itemList", itemSearchRepository.searchItems(search));
		sellIn.addAttribute("search", search);
		return "home";
	}
	
    @RequestMapping(value = "/home", method = RequestMethod.DELETE)
    public String delete(@RequestParam String id) {
        Item item = itemRepository.findOne(id);
        itemRepository.delete(item);
        return "home";
    }	
}
