package com.tests4geeks.tutorials.model;

import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "items")
public class Item {

	private String id;
	
	private String name;
	
	private String sellIn;
	
	private String quality;
	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSellIn() {
		return sellIn;
	}

	public void setSellIn(String sellIn) {
		this.sellIn = sellIn;
	}

	public String getQuality() {
		return quality;
	}

	public void setQuality(String quality) {
		this.quality = quality;
	}
	
}
